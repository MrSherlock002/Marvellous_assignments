////////////////////////////
//
//It is used accept one number from user and print that number of * on screen	
//
////////////////////////////

#include "header.h"

//Entry point function

int main()
{
int iValue = 0;				//Declaration of iValue1
printf("Enter the number");		//Accepting the input from user.
scanf("%d",&iValue);

Display(iValue);			//Calling the Display()
return 0;				//return the success to OS

}