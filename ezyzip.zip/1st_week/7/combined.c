/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger 
// Output :		Character
// Description :	It is used accept one number from user and print that number of * on screen	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

//Accept one number from user and print that number of * on screen

#include<stdio.h>

void Display (int iNo)
{
    while (iNo>0)
    {
        printf("*");
        iNo--;
    }
}

int main()
{
int iValue = 0;
printf("Enter the number");
scanf("%d",&iValue);

Display(iValue);
return 0;
}