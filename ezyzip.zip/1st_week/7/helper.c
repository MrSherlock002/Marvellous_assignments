/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger 
// Output :		Character
// Description :	It is used accept one number from user and print that number of * on screen	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

/*
	Algorithm
	START
	 declare iValue to 0
	 Call the Display()
	 Print the *
	END
*/

#include "header.h"
void Display ( 
		 int iNo    //First input argument
	        )
{

while (iNo>0)
    {
        printf("*");
        iNo--;
    }

}
