/////////////////////////////////////
//
// Function name : 	ChkEvent 
// Input :		Interger
// Output :		Boolean
// Description :	Accept number from the user and check whether number is even or odd	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

//Accept number from the user and check whether number is even or odd

# include<stdio.h>

#define TRUE 1
#define FALSE 0

typedef int BOOL;
BOOL ChkEvent(int iNo)
{
    if (iNo%2 == 0)
    {
    return TRUE;
    }
    else
    {
        return FALSE;
    }
}

int main()
{
    int iValue =0;
    BOOL bRet = FALSE;

    printf("Enter number");
    scanf("%d",&iValue);

    bRet = ChkEvent(iValue);
    if (bRet == TRUE)
    {
        printf("Given number %d even",iValue);
    }
    else
    {
        printf("Given number %d odd",iValue);
    }

 return 0;
}