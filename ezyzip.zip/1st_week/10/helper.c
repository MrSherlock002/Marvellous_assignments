/////////////////////////////////////
//
// Function name : 	ChkEvent 
// Input :		Interger
// Output :		Boolean
// Description :	Accept number from the user and check whether number is even or odd	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

/*
	Algorithm
	START
	 declare iValue1 to 0
	 declare boolean return value as FALSE
	 Perform ChkEvent()
	 Return the value of bRet
	 check the condition and print the output
	END
*/

#include "header.h"
BOOL ChkEvent( 
		 int iNo    //First input argument
	       )
{
    if (iNo%2==0)			//Checking the if condition
    {
    return TRUE;
    }
    else
    {
        return FALSE;
    }
}






