//Header file inclusion
#include <stdio.h>

//Function prototype
#define TRUE 1
#define FALSE 0

typedef int BOOL;
BOOL ChkEvent(int iNo);