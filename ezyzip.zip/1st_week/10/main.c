////////////////////////////
//
//Accept number from the user and check whether number is even or odd	
//
////////////////////////////

#include "header.h"

//Entry point function

int main()
{
    int iValue=0;				//Declaration of iValue1
    BOOL bRet=FALSE;

    printf("Enter number");			//Accepting iValue from the user
    scanf("%d",&iValue);

    bRet = ChkEvent(iValue);

    if (bRet==TRUE)
    {
        printf("Given number %d even",iValue);
    }
    else
    {
        printf("Given number %d odd",iValue);
    }

 return 0;					//return success to OS
}