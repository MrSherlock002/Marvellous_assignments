/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger 
// Output :		Integer
// Description :	It is used to print 5 to 1	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

/*
	Algorithm
	START
	Perform function Display()
	set i = 0
	Check i from 5 t o1
	Print the value of i
	END
*/

#include "header.h"
void Display ()
{
int i = 0;			// Set the value of i to 0 
    //i = 5;
    for (i = 5; i>0; i--)		//i-=2)
    {
        printf("%d\t",i--); 		//i)
        i++;
    }

int iAns = 0;			//Local variable to store result

}
