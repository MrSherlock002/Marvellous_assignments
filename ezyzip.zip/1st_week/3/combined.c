/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger 
// Output :		Integer
// Description :	It is used to print 5 to 1	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

# include<stdio.h>

void Display()
{
    int i = 0;
    //i = 5;
    for (i = 5; i>0; i--)//i-=2)
    {
        printf("%d\t",i--); //i)
        i++;
    }
}

int main()
{
 Display();
 
 return 0;
}