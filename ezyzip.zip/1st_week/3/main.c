////////////////////////////
//
//Program to print 5 to 1 numbers on screen
//
////////////////////////////

#include "header.h"

//Entry point function

int main ()
{

Display();  		//calling the Display function

return 0;		//Return success to OS.
}