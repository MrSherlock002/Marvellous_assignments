////////////////////////////
//
//Accept one number from user if number is less than 10 then print "Hello" otherwise print "Demo"
//
////////////////////////////

#include "header.h"

//Entry point function

int main()
{
int iValue = 0;				//define iValue to 0
printf("Enter the number");		//Accepting number from user
scanf("%d",&iValue);

Display(iValue);			//Calling Display()
return 0;				//Return success value to OS 
}