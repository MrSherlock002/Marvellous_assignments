/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger
// Output :		Character
// Description :	Accept one number from user if number is less than 10 then print "Hello" otherwise print "Demo"
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

//Accept one number from user if number is less than 10 then print "Hello" otherwise print "Demo"

#include<stdio.h>

void Display (int iNo)
{
    if (iNo < 10 )
    {
        printf("Hello");
    }
    else 
    {
        printf("Demo");
    }
}

int main()
{
int iValue = 0;
printf("Enter the number");
scanf("%d",&iValue);

Display(iValue);
return 0;
}