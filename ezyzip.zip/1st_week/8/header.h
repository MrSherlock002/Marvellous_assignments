//Header file inclusion
#include <stdio.h>

//Function prototype
void Display(int);