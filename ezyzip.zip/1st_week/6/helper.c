/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger
// Output :		Integer
// Description :	Accept one number from user and print * that number of time.	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

/*
	Algorithm
	START
	 declare iValue = 0;
	 Accept iValue from the user
	 Call the Display()
	END
*/

#include "header.h"
void Display ( 
		 int iNo    //First input argument
	     )
{
int iCnt = 0;			//Local looping variable set to 0

for (iCnt = 0; iCnt<iNo; iCnt++)
    {
        printf("*");			//Printing the *
    }

}