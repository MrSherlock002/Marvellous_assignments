////////////////////////////
//
//Accept one number from user and print * that number of time.	
//
////////////////////////////

#include "header.h"

//Entry point function

int main()
{
int iValue = 0;					//Declaration of iValue
printf("Enter the number");			//Accepting the input from user
scanf("%d",&iValue);

Display(iValue);				//Calling the Display function
return 0;					//return the success to OS
}