/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger
// Output :		Integer
// Description :	Accept one number from user and print * that number of time.	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////



#include<stdio.h>

void Display (int iNo)
{
    int iCnt = 0;
    for (iCnt = 0; iCnt<iNo; iCnt++)
    {
        printf("*");
    }
}

int main()
{
int iValue = 0;
printf("Enter the number");
scanf("%d",&iValue);

Display(iValue);
return 0;
}