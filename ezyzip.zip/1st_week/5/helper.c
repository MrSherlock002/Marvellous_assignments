/////////////////////////////////////
//
// Function name : 	Accept 
// Input :		Interger
// Output :		character
// Description :	It is used to print * on screen equals to input value	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

/*
	Algorithm
	START
	 declare iValue1
	 Perform Accept()
	checking the iCnt 0 to 5
	return the value of Accept()
	END
*/

#include "header.h"
void Accept ( 
		 int iNo1    //First input argument
	   )
{
int iCnt = 0;			//Local variable to store result
 for (iCnt = 0; iCnt<iNo1; iCnt++)
    {
        printf("*");
    }

}
