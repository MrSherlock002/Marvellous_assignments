////////////////////////////
//
//It is used to print * on screen equals to input value	
//
////////////////////////////

#include "header.h"

//Entry point function

int main()
{
int iValue = 0;			//Declaration of iValue1
iValue = 5;			//Declaration of iValue1

Accept(iValue);			//Calling the Accept()
return 0;			//Return the value with success

}