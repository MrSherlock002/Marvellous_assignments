/////////////////////////////////////
//
// Function name : 	Check
// Input :		Interger 
// Output :		Integer
// Description :	It is used to check number is divisible by 5 or not	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////


#include<stdio.h>

typedef int BOOL;
#define TRUE 1
#define FALSE 0

int Check (int iNo1)
{
    if((iNo1%5)==0)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

int main()
{
int iValue = 0;
BOOL bRet = FALSE;

printf("Enter Number ");
scanf("%d",&iValue);

bRet = Check(iValue);

if (bRet==TRUE)
{
    printf("%d Divisible by 5",iValue);
}
else
{
printf("%d Not Divisible by 5",iValue);
}

return 0;
}