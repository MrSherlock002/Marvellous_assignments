/////////////////////////////////////
//
// Function name : 	Check
// Input :		Interger 
// Output :		Integer
// Description :	It is used to check number is divisible by 5 or not	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

/*
	Algorithm
	START
	set iValue = 0
	set bRet = FALSE
	Accept the iValue from user
	Calling the Check() 
	Return the value of Check() TRUE or FALSE
	Checking the if Condition 
	printing the result
	END
*/

#include "header.h"
int Check ( 
		 int iNo1    //First input argument
	   )
{
if((iNo1%5)==0)			//Finding reminder
    {
        return TRUE;		//return value if Condition  true
    }
    else
    {
        return FALSE;		//return value if condition false
    }
}
