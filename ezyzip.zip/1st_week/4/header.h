//Header file inclusion
#include <stdio.h>

//Function prototype
typedef int BOOL;
#define TRUE 1
#define FALSE 0

int Check(int);