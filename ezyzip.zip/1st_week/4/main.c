////////////////////////////
//
// It is used to check wheather number is divisible by 5 or not	
//
////////////////////////////

#include "header.h"

//Entry point function

int main()
{
int iValue = 0;
BOOL bRet = FALSE;

printf("Enter Number ");
scanf("%d",&iValue);			//Accepting the iValue

bRet = Check(iValue);			//Calling the Check()

if (bRet==TRUE)
{
    printf("%d Divisible by 5",iValue);		//Print iValue if condition is true
}
else
{
printf("%d Not Divisible by 5",iValue);
}

return 0;
}

