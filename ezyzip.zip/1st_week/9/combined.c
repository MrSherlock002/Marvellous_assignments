/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger, Integer 
// Output :		Integer
// Description :	Accept two numbers from user and display first number in second number of times
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////


//Accept two numbers from user and display first number in second number of times

#include<stdio.h>

void Display (int iNo, int iFrequency)
{
    if (iFrequency<0)
    {
        iFrequency = -iFrequency;
    }
    int iCnt = 0;
    for (iCnt= 0 ; iCnt<iFrequency; iCnt++ )
    {
        printf("%d\t",iNo);
    }
    
}

int main()
{
int iValue = 0;
int iCount = 0;

printf("Enter the number");
scanf("%d",&iValue);

printf("Enter Frequency");
scanf("%d",&iCount);

Display(iValue,iCount);
return 0;
}