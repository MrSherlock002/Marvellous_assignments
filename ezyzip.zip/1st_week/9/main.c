////////////////////////////
//
//Accept two numbers from user and display first number in second number of times
//
////////////////////////////

#include "header.h"

//Entry point function

int main()
{
int iValue = 0;			//Setting the iValue to the 0
int iCount = 0;			//Setting the iValue to the 0

printf("Enter the number");	//Getting iValue from user
scanf("%d",&iValue);

printf("Enter Frequency");	//Getting iFrequency from user
scanf("%d",&iCount);

Display(iValue,iCount);		//Calling the Display function
return 0;
}