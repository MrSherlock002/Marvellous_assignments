/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger, Integer 
// Output :		Integer
// Description :	Accept two numbers from user and display first number in second number of times
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

/*
	Algorithm
	START
	 declare first number as iValue
	 declare second number as iFrequency
	 Perform Display() with iNo,iFrequency
	 Print the output
	END
*/

#include "header.h"
void Display ( 
		 int iNo,    //First input argument
		 int iFrequency     //Second input argument
	     )
{
 if (iFrequency<0)     				//If iFrequency is minus value
    {
        iFrequency = -iFrequency;
    }
    int iCnt = 0;				//setting iCnt to 0;
    for (iCnt= 0 ; iCnt<iFrequency; iCnt++ )
    {
        printf("%d\t",iNo);			//print the op if condition is TRUE
    }
}