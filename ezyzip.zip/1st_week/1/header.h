//Header file inclusion
#include <stdio.h>

//Function prototype
int Divide(int,int);