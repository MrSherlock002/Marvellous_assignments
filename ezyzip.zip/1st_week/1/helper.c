/////////////////////////////////////
//
// Function name : 	Divide 
// Input :		Interger, Integer 
// Output :		Integer
// Description :	It is used to divide the two numbers	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

/*
	Algorithm
	START
	 declare first number as iValue1
	 declare second number as iValue2
	 Perform dividation of iNo1 & iNo2
	 Store the result in iAns
	 Return the value of iRet
	END
*/

#include "header.h"
int Divide ( 
		 int iNo1,    //First input argument
		 int iNo2     //Second input argument
	     )
{
int iAns = 0;			//Local variable to store result

if(iNo2<0)
{
return -1;			//return this value if condition is TRUE
}

iAns = iNo1 / iNo2;
return iAns;			//return the value to the caller.
}
