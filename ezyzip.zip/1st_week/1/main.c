////////////////////////////
//
//Program to divide two numbers
//
////////////////////////////

#include "header.h"

//Entry point function

int main ()
{

 int iValue1 =15 ,		//Declaration of iValue1
 iValue2 = 5; 			//Declaration of iValue2
 int iRet = 0;			//Declaration of iRet

 iRet = Divide(iValue1, iValue2);			//Calling the Divide Function
 printf("Division is %d",iRet); 			//Printing the output

return 0;						//Return success to OS.
}