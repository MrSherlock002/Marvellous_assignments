/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger 
// Output :		Character
// Description :	It is used to print Marvellous 5 times 	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

/*
	Algorithm
	START
	set integer variable i = 0
	check i = 1 to i =5	 	 
	Perform Display()
	END
*/

#include "header.h"
void Display ()
{
int i = 0;			//Local variable to store result

	for (i=1; i<=5; i++)
	{
	printf("Marvellous\n");
	}			//return the value to the caller.
}
