////////////////////////////
//
//Program to print 5 times Marvellous on screen
//
////////////////////////////

#include "header.h"

//Entry point function

int main()
{
 Display();			//Calling the Display Function
 
 return 0;			//Return success to OS.
}

