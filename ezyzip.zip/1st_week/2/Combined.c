/////////////////////////////////////
//
// Function name : 	Display 
// Input :		Interger 
// Output :		Character
// Description :	It is used to print Marvellous 5 times 	
// Author :		Prasad Ramchandra Bhosale
// Date :		05/09/2021
//
/////////////////////////////////////

# include<stdio.h>

void Display()
{
    int i = 0;
    for (i = 1; i<=5; i++)
    {
        printf("Marvellous\n");
    }
}

int main()
{
 Display();
 
 return 0;
}